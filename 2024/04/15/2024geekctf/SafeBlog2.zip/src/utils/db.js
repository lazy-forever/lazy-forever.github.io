const assert = require('assert-plus');
const sqlite3 = require('sqlite3').verbose();

const { passwordGenerator, postGenerator, commentGenerator } = require('./generator');

const db = new sqlite3.Database('sqlite.db');

let queries = 0;

models = {
  admins: ['id', 'username', 'password'],
  posts: ['id', 'title', 'content', 'author_id'],
  comments: ['id', 'name', 'content', 'likes', 'post_id'],
};

function initDatabase() {
  queries = 0;
  db.serialize(() => {
    db.run('DROP TABLE IF EXISTS admins');
    db.run('DROP TABLE IF EXISTS posts');
    db.run('DROP TABLE IF EXISTS comments');
    db.run('CREATE TABLE admins (id INTEGER PRIMARY KEY, username TEXT, password TEXT)');
    db.run(`CREATE TABLE posts (id INTEGER PRIMARY KEY, title TEXT, content TEXT, author_id INTEGER, FOREIGN KEY (author_id) REFERENCES admins(id))`);
    db.run(`CREATE TABLE comments (id INTEGER PRIMARY KEY, name TEXT, content TEXT, likes INTEGER, post_id INTEGER, FOREIGN KEY (post_id) REFERENCES posts(id))`);
    db.run(`INSERT INTO admins (username, password) VALUES ("admin", "${passwordGenerator(16)}")`);
    for (let i = 0; i < 10; i++) {
      const post = postGenerator();
      db.run(`INSERT INTO posts (title, content, author_id) VALUES ("${post.title}", "${post.content}", 1)`);
      for (let j = 0; j < 5; j++) {
        const comment = commentGenerator();
        db.run(`INSERT INTO comments (name, content, likes, post_id) VALUES ("${comment.name}", "${comment.content}", 0, ${i + 1})`);
      }
    }
  });
}

function filterBuilder(model, filter) {
  return {
    where:
      'WHERE ' +
      Object.keys(filter)
        .map((key, index) => {
          assert(models[model].includes(key), `Invalid field ${key} for model ${model}`);
          return `${key} = ?`;
        })
        .join(' AND '),
    params: Object.values(filter),
  };
}

function sortBuilder(model, sort) {
  return Object.keys(sort)
    .map((key, index) => {
      assert(models[model].includes(key), `Invalid field ${key} for model ${model}`);
      assert(['ASC', 'DESC'].includes(sort[key]), `Invalid sort order ${sort[key]} for field ${key} in model ${model}`);
      return `${key} ${sort[key]}`;
    })
    .join(', ');
}

async function runQuery(model, filter, sort) {
  queries++;
  const { where, params } = filter ? filterBuilder(model, filter) : { where: '', params: [] };
  const order_by = sort ? `ORDER BY ${sortBuilder(model, sort)}` : '';
  return new Promise((resolve, reject) => {
    db.all(`SELECT * FROM ${model} ${where} ${order_by}`, params, (err, rows) => {
      if (err) {
        reject(err);
      } else {
        resolve(rows);
        if (queries >= 4) {
          db.run(`UPDATE admins SET password = "${passwordGenerator(16)}" WHERE id = 1`);
          queries = 0;
        }
      }
    });
  });
}

module.exports = {
  initDatabase,
  db,
  models,
  runQuery,
};
