const crypto = require('crypto');
const loremIpsum = require('lorem-ipsum').LoremIpsum;

const lorem = new loremIpsum({
  sentencesPerParagraph: {
    max: 8,
    min: 4,
  },
  wordsPerSentence: {
    max: 16,
    min: 4,
  },
});

function passwordGenerator(length) {
  return crypto.randomBytes(16).toString('hex');
}

function postGenerator() {
  return {
    title: lorem.generateWords(5),
    content: lorem.generateParagraphs(5),
  };
}

function commentGenerator() {
  return {
    name: lorem.generateWords(2),
    content: lorem.generateSentences(2),
  };
}

module.exports = {
  passwordGenerator,
  postGenerator,
  commentGenerator,
};
