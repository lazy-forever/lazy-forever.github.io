const express = require('express');

const { db, initDatabase, runQuery } = require('./utils/db');

const app = express();

app.set('views', './views');
app.set('view engine', 'ejs');
app.use(express.static('public'));

initDatabase();

app.get('/', async (req, res) => {
  try {
    const posts = await runQuery('posts', null, { id: 'DESC' });
    res.render('index', { posts });
  } catch {
    res.status(500).render('error', { message: 'Internal Server Error' });
  }
});

app.get('/archives', async (req, res) => {
  try {
    const posts = await runQuery('posts', null, { id: 'DESC' });
    res.render('archives', { posts });
  } catch {
    res.status(500).render('error', { message: 'Internal Server Error' });
  }
});

app.get('/post/:id', async (req, res) => {
  try {
    const posts = await runQuery('posts', req.params);
    posts.forEach(async (post) => {
      post.comments = await runQuery('comments', { post_id: post.id }, { likes: 'DESC' });
      res.render('post', { post });
    });
    if (posts.length === 0) {
      res.status(404).render('error', { message: 'Post not found' });
    }
  } catch {
    res.status(500).render('error', { message: 'Internal Server Error' });
  }
});

app.get('/comment/new', async (req, res) => {
  try {
    const { name, content, post_id } = req.query;
    db.run('INSERT INTO comments (name, content, likes, post_id) VALUES (?, ?, 0, ?)', name, content, post_id);
    res.redirect(req.headers.referer ?? '/');
  } catch {
    res.status(500).render('error', { message: 'Internal Server Error' });
  }
});

app.get('/comment/like', async (req, res) => {
  try {
    const comments = await runQuery('comments', req.query);
    comments.forEach((comment) => {
      db.run('UPDATE comments SET likes = likes + 1 WHERE id = ?', comment.id);
    });
    res.redirect(req.headers.referer ?? '/');
  } catch {
    res.status(500).render('error', { message: 'Internal Server Error' });
  }
});

app.get('/tags', (req, res) => {
  res.render('tags');
});

app.get('/links', (req, res) => {
  res.render('links');
});

app.get('/about', (req, res) => {
  const uptime = process.uptime();
  const format = (bytes) => {
    return (bytes / 1024 / 1024).toFixed(2) + 'MB';
  };
  const memoryUsage = {
    rss: format(process.memoryUsage().rss),
    heapTotal: format(process.memoryUsage().heapTotal),
    heapUsed: format(process.memoryUsage().heapUsed),
    external: format(process.memoryUsage().external),
  };
  res.render('about', { uptime, memoryUsage });
});

app.get('/admin', async (req, res) => {
  try {
    const { username, password } = req.query;
    const admins = await runQuery('admins', { username, password });
    if (admins.length === 0) {
      res.render('login', { message: 'Invalid credentials' });
      return;
    }
    res.render('admin', { flag: process.env.FLAG });
  } catch {
    res.status(500).render('error', { message: 'Internal Server Error' });
  }
});

app.use((req, res) => {
  res.status(404).render('error', { message: 'Page not found' });
});

app.listen(process.env.PORT || 80, process.env.HOST || '0.0.0.0', () => {
  console.log('Server started.');
});
