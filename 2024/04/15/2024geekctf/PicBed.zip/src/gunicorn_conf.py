import gunicorn

gunicorn.SERVER = "PicBed"
bind = "0.0.0.0:80"
workers = 4
