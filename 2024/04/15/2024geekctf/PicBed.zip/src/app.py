import os
import re
import socket
import time
from urllib.parse import unquote_plus

from flask import Flask, abort, redirect, render_template, request

app = Flask(
    __name__, static_url_path="/", static_folder="assets", template_folder="templates"
)


def fetch_converted_image(path, accept, timeout=0.5):
    """
    Send user request to webp server and get the converted image
    """
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect(("127.0.0.1", 3333))
    s.send(
        f"GET /{path} HTTP/1.1\r\nAccept: {accept}\r\nConnection: close\r\n\r\n".encode()
    )
    chunks = []
    begin = time.time()
    while True:
        if time.time() - begin > timeout:
            break
        try:
            data = s.recv(4096)
            chunks.append(data)
        except:
            pass
    chunks = b"".join(chunks)
    image = chunks.split(b"\r\n\r\n")[-1]
    type = re.search(b"Content-Type: ([^\r\n]+)", chunks).group(1)
    return image, type.decode() if type else "text/plain"


@app.route("/")
def index():
    pics = os.listdir("pics")
    return render_template("index.html", pics=pics)


@app.route("/upload", methods=["POST"])
def upload():
    pic = request.files["pic"]
    ext = pic.filename.split(".")[-1]
    if not ext.isalnum():
        pics = os.listdir("pics")
        return render_template("index.html", error="Invalid image file.", pics=pics)
    pic.save(f"pics/{os.urandom(8).hex()}.{ext}")
    return redirect("/")


@app.route("/pics/<string:path>")
def pics(path):
    if path not in os.listdir("pics"):
        abort(404)
    accept = unquote_plus(request.headers.get("Accept"))
    img, type = fetch_converted_image(path, accept)
    return img, 200, {"Content-Type": type}


if __name__ == "__main__":
    app.run()
