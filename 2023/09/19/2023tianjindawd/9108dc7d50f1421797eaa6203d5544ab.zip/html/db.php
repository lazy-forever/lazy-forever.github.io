<?php

/**
 * 配置文件
 */
return array(
    'DB_TYPE' => 'mysql',
    'DB_HOST' => '127.0.0.1',
    'DB_NAME' => 'supercms',
    'DB_USER' => 'cms',
    'DB_PWD' => 'shee>f7Hee{ma7oo',
    'DB_PORT' => '3306',
    'DB_PREFIX' => 'sn_',
 
    //cookies
    "COOKIE_PREFIX" => 'okeTJ4_',
);
?>