<div class="header">
    <h1 class="logo">logo</h1>
    <div class="icon_install">安装向导</div>
    <div class="version"><a style="color:#fff" href="http://www.bijiadao.net">官网支持>></a>：<?php echo SIMPLEWIND_CMF_VERSION;?></div>
  </div>