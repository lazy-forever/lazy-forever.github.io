import os

file_path = "/var/www/html/config/config.php"

try:
    os.remove(file_path)
    print(f"File {file_path} has been successfully deleted.")
except OSError as e:
    print(f"Error deleting {file_path}: {e}")
