#!/bin/bash
python3 patch.py 
cp index.class.php /var/www/html/controller/index.class.php
