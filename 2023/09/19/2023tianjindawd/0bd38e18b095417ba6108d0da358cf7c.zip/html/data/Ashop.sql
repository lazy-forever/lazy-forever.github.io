-- MySQL dump 10.13  Distrib 5.7.23, for Linux (x86_64)
--
-- Host: localhost    Database: Ashop
-- ------------------------------------------------------
-- Server version	5.7.23-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `shop_cat`
--

DROP TABLE IF EXISTS `shop_cat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shop_cat` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `catname` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `catname` (`catname`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_cat`
--

LOCK TABLES `shop_cat` WRITE;
/*!40000 ALTER TABLE `shop_cat` DISABLE KEYS */;
INSERT INTO `shop_cat` VALUES (11,'电子产品'),(12,'衣服'),(10,'食物');
/*!40000 ALTER TABLE `shop_cat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_content`
--

DROP TABLE IF EXISTS `shop_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shop_content` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `cat` int(8) NOT NULL,
  `date` date NOT NULL,
  `picture` varchar(200) NOT NULL,
  `url` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cat` (`cat`),
  CONSTRAINT `shop_content_ibfk_1` FOREIGN KEY (`cat`) REFERENCES `shop_cat` (`id`) ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_content`
--

LOCK TABLES `shop_content` WRITE;
/*!40000 ALTER TABLE `shop_content` DISABLE KEYS */;
INSERT INTO `shop_content` VALUES (88,'mi8',11,'2018-08-23','static/img/goods/mi8.jpg','static/img/goods/mi8.jpg'),(89,'mi8',11,'2018-08-19','static/img/goods/mi8.jpg','static/img/goods/mi8.jpg'),(90,'mi8',11,'2018-08-15','static/img/goods/mi8.jpg','static/img/goods/mi8.jpg'),(91,'mi8',11,'2018-08-11','static/img/goods/mi8.jpg','static/img/goods/mi8.jpg'),(92,'iphonex',11,'2018-08-12','static/img/goods/iphonex.jpg','static/img/goods/iphonex.jpg'),(93,'iphonex',11,'2018-08-16','static/img/goods/iphonex.jpg','static/img/goods/iphonex.jpg'),(94,'iphonex',11,'2018-08-20','static/img/goods/iphonex.jpg','static/img/goods/iphonex.jpg'),(95,'iphonex',11,'2018-08-24','static/img/goods/iphonex.jpg','static/img/goods/iphonex.jpg'),(96,'t-shirt',12,'2018-08-13','static/img/goods/t-shirt.jpg','static/img/goods/t-shirt.jpg'),(97,'t-shirt',12,'2018-08-17','static/img/goods/t-shirt.jpg','static/img/goods/t-shirt.jpg'),(98,'t-shirt',12,'2018-08-21','static/img/goods/t-shirt.jpg','static/img/goods/t-shirt.jpg'),(99,'cola',10,'2018-08-14','static/img/goods/cola.jpg','static/img/goods/cola.jpg'),(100,'cola',10,'2018-08-18','static/img/goods/cola.jpg','static/img/goods/cola.jpg'),(101,'cola',10,'2018-08-22','static/img/goods/cola.jpg','static/img/goods/cola.jpg');
/*!40000 ALTER TABLE `shop_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_user`
--

DROP TABLE IF EXISTS `shop_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shop_user` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_user`
--

LOCK TABLES `shop_user` WRITE;
/*!40000 ALTER TABLE `shop_user` DISABLE KEYS */;
INSERT INTO `shop_user` VALUES (1,'admin','21232f297a57a5a743894a0e4a801fc3');
/*!40000 ALTER TABLE `shop_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-08-12 22:33:19
