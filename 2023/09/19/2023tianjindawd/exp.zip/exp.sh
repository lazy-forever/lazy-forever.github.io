#!/bin/bash
python3 exp.py $1 $2 
